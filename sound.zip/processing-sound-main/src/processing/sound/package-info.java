/**
 * <b>This Javadoc is only provided as reference for advanced users.</b> It might describe functionality that is not yet available in official Sound library releases, but only in development test builds that can be downloaded from Github. New functionality might still be subject to change. <b>For the basic documentation of the Processing Sound library with examples, please see <a href="https://processing.org/reference/libraries/sound/" target="_top">https://processing.org/reference/libraries/sound/</a>.</b>
 */
package processing.sound;
