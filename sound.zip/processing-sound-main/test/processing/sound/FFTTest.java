package processing.sound;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class FFTTest {

	@Test
	public void testSomething() {
		assertEquals(2, 1+1);
	}
}

